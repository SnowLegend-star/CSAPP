/*
 * 7.7
 *
 * mofaph@gmail.com
 */

/*
 * Solution 1
 */

int x;

void f()
{
        x = 15213;
}

/*
 * Solution 2
 */
double x;
void f()
{
        return;
        x = -0.0;
}

/*
 * Solution 3
 */

/* double x; */

void f()
{
        /* x = -0.0; */
}
