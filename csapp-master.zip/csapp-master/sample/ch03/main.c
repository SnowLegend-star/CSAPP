/*
 * p109
 *
 * unix> gcc -O1 -o prog code.o main.c
 */

int main()
{
        return sum(1, 3);
}
