/*
 * unix> gcc -O1 -S -m32 simple_1.c -o code32.s
 *
 * 或者
 *
 * unix> gcc -O1 -S -m64 simple_1.c -o code64.s
 */

long int simple_1(long int *xp, long int y)
{
        long int t = *xp + t;
        *xp = t;
        return t;
}
