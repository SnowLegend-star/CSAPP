/*
 * bar1.c -- p455
 */
int main()
{
        return 0;
}
