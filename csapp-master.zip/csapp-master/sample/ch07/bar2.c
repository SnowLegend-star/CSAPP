/*
 * bar2.c -- p455
 */
int x = 15213;

void f()
{
}
