/*
 * bar3.c -- p455
 */
int x;

void f()
{
        x = 15212;
}
