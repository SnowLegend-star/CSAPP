/*
 * bar4.c -- p456
 */

int x;

void f()
{
        x = 15212;
}
