/*
 * bar5.c -- p456
 */

double x;

void f()
{
        x = -0.0;
}
