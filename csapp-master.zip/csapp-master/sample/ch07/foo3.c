/*
 * foo3.c -- p455~p456
 */

#include <stdio.h>
void f(void);

int x = 15213;

int main()
{
        f();
        printf("x = %d\n", x);
        return 0;
}
