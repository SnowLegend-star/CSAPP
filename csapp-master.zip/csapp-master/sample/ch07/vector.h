extern void multvec(int *x, int *y, int *z, int n);
extern void addvec(int *x, int *y, int *z, int n);
